<?php
/**
 * ASSE REST API — Remote management endpoints for AgentSocial DFY service
 * 
 * All endpoints require authentication via WordPress application passwords.
 * Base: /wp-json/asse/v1/
 */
class ASSE_REST_API {

    private $namespace = 'asse/v1';

    public function register_routes() {
        // Business info
        register_rest_route( $this->namespace, '/business', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_business' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/business', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'update_business' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);

        // FAQ
        register_rest_route( $this->namespace, '/faqs', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_faqs' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/faqs', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_faq' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/faqs/(?P<id>\d+)', [
            'methods'             => 'PUT',
            'callback'            => [ $this, 'update_faq' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/faqs/(?P<id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_faq' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);

        // Services
        register_rest_route( $this->namespace, '/services', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_services' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/services', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_service' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/services/(?P<id>\d+)', [
            'methods'             => 'PUT',
            'callback'            => [ $this, 'update_service' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/services/(?P<id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_service' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);

        // Reviews
        register_rest_route( $this->namespace, '/reviews', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_reviews' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/reviews', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_review' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/reviews/(?P<id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_review' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);

        // Team
        register_rest_route( $this->namespace, '/team', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_team' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/team', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_team_member' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/team/(?P<id>\d+)', [
            'methods'             => 'PUT',
            'callback'            => [ $this, 'update_team_member' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
        register_rest_route( $this->namespace, '/team/(?P<id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_team_member' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);

        // Schema preview (GET — returns generated JSON-LD without auth for testing)
        register_rest_route( $this->namespace, '/schema-preview', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_schema_preview' ],
            'permission_callback' => '__return_true', // Public for testing
        ]);

        // Health check
        register_rest_route( $this->namespace, '/health', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'health_check' ],
            'permission_callback' => '__return_true',
        ]);
    }

    public function check_permission() {
        return current_user_can( 'manage_options' );
    }

    // ---- Business ----

    public function get_business( $request ) {
        $fields = [
            'business_name', 'business_description', 'business_type',
            'street_address', 'city', 'state', 'postal_code', 'country',
            'phone', 'email', 'website', 'latitude', 'longitude',
            'price_range', 'image', 'logo', 'hours', 'same_as', 'enabled',
            'faq_enabled', 'services_enabled', 'reviews_enabled', 'team_enabled',
        ];
        $data = [];
        foreach ( $fields as $f ) {
            $data[ $f ] = get_option( 'asse_' . $f );
        }
        return rest_ensure_response( $data );
    }

    public function update_business( $request ) {
        $params = $request->get_json_params();
        if ( empty( $params ) ) {
            $params = $request->get_body_params();
        }

        $allowed = [
            'business_name', 'business_description', 'business_type',
            'street_address', 'city', 'state', 'postal_code', 'country',
            'phone', 'email', 'website', 'latitude', 'longitude',
            'price_range', 'image', 'logo', 'enabled',
            'faq_enabled', 'services_enabled', 'reviews_enabled', 'team_enabled',
        ];

        $updated = [];
        foreach ( $allowed as $field ) {
            if ( isset( $params[ $field ] ) ) {
                update_option( 'asse_' . $field, sanitize_text_field( $params[ $field ] ) );
                $updated[] = $field;
            }
        }

        // Hours (array)
        if ( isset( $params['hours'] ) && is_array( $params['hours'] ) ) {
            $clean = [];
            foreach ( $params['hours'] as $h ) {
                if ( ! empty( $h['days'] ) && ! empty( $h['open'] ) && ! empty( $h['close'] ) ) {
                    $clean[] = [
                        'days'  => array_map( 'sanitize_text_field', (array) $h['days'] ),
                        'open'  => sanitize_text_field( $h['open'] ),
                        'close' => sanitize_text_field( $h['close'] ),
                    ];
                }
            }
            update_option( 'asse_hours', $clean );
            $updated[] = 'hours';
        }

        // SameAs (array)
        if ( isset( $params['same_as'] ) && is_array( $params['same_as'] ) ) {
            update_option( 'asse_same_as', array_map( 'esc_url_raw', array_filter( $params['same_as'] ) ) );
            $updated[] = 'same_as';
        }

        return rest_ensure_response( [ 'updated' => $updated, 'status' => 'ok' ] );
    }

    // ---- FAQ ----

    public function get_faqs() {
        $store = new ASSE_Data_Store();
        return rest_ensure_response( $store->get_faqs() );
    }

    public function create_faq( $request ) {
        $params = $request->get_json_params() ?: $request->get_body_params();
        if ( empty( $params['question'] ) || empty( $params['answer'] ) ) {
            return new WP_Error( 'missing_fields', 'Question and answer are required', [ 'status' => 400 ] );
        }
        $id = wp_insert_post( [
            'post_type'    => 'asse_faq',
            'post_title'   => sanitize_text_field( $params['question'] ),
            'post_content' => wp_kses_post( $params['answer'] ),
            'post_status'  => 'publish',
        ]);
        return rest_ensure_response( [ 'id' => $id, 'question' => $params['question'], 'status' => 'created' ] );
    }

    public function update_faq( $request ) {
        $id = $request['id'];
        $params = $request->get_json_params() ?: $request->get_body_params();
        $update = [];
        if ( isset( $params['question'] ) ) $update['post_title'] = sanitize_text_field( $params['question'] );
        if ( isset( $params['answer'] ) ) $update['post_content'] = wp_kses_post( $params['answer'] );
        $update['ID'] = $id;
        wp_update_post( $update );
        return rest_ensure_response( [ 'id' => $id, 'status' => 'updated' ] );
    }

    public function delete_faq( $request ) {
        wp_delete_post( $request['id'], true );
        return rest_ensure_response( [ 'id' => $request['id'], 'status' => 'deleted' ] );
    }

    // ---- Services ----

    public function get_services() {
        $store = new ASSE_Data_Store();
        return rest_ensure_response( $store->get_services() );
    }

    public function create_service( $request ) {
        $params = $request->get_json_params() ?: $request->get_body_params();
        if ( empty( $params['name'] ) ) {
            return new WP_Error( 'missing_fields', 'Service name is required', [ 'status' => 400 ] );
        }
        $id = wp_insert_post( [
            'post_type'    => 'asse_service',
            'post_title'   => sanitize_text_field( $params['name'] ),
            'post_content' => wp_kses_post( $params['description'] ?? '' ),
            'post_status'  => 'publish',
        ]);
        if ( ! empty( $params['category'] ) ) {
            update_post_meta( $id, '_asse_service_category', sanitize_text_field( $params['category'] ) );
        }
        return rest_ensure_response( [ 'id' => $id, 'name' => $params['name'], 'status' => 'created' ] );
    }

    public function update_service( $request ) {
        $id = $request['id'];
        $params = $request->get_json_params() ?: $request->get_body_params();
        $update = [ 'ID' => $id ];
        if ( isset( $params['name'] ) ) $update['post_title'] = sanitize_text_field( $params['name'] );
        if ( isset( $params['description'] ) ) $update['post_content'] = wp_kses_post( $params['description'] );
        wp_update_post( $update );
        if ( isset( $params['category'] ) ) {
            update_post_meta( $id, '_asse_service_category', sanitize_text_field( $params['category'] ) );
        }
        return rest_ensure_response( [ 'id' => $id, 'status' => 'updated' ] );
    }

    public function delete_service( $request ) {
        wp_delete_post( $request['id'], true );
        return rest_ensure_response( [ 'id' => $request['id'], 'status' => 'deleted' ] );
    }

    // ---- Reviews ----

    public function get_reviews() {
        $store = new ASSE_Data_Store();
        return rest_ensure_response( $store->get_reviews() );
    }

    public function create_review( $request ) {
        $params = $request->get_json_params() ?: $request->get_body_params();
        if ( empty( $params['text'] ) ) {
            return new WP_Error( 'missing_fields', 'Review text is required', [ 'status' => 400 ] );
        }
        $id = wp_insert_post( [
            'post_type'    => 'asse_review',
            'post_title'   => sanitize_text_field( $params['author'] ?? 'Anonymous' ),
            'post_content' => wp_kses_post( $params['text'] ),
            'post_status'  => 'publish',
        ]);
        update_post_meta( $id, '_asse_review_rating', absint( $params['rating'] ?? 5 ) );
        update_post_meta( $id, '_asse_review_author', sanitize_text_field( $params['author'] ?? 'Anonymous' ) );
        if ( ! empty( $params['date'] ) ) {
            update_post_meta( $id, '_asse_review_date', sanitize_text_field( $params['date'] ) );
        }
        return rest_ensure_response( [ 'id' => $id, 'status' => 'created' ] );
    }

    public function delete_review( $request ) {
        wp_delete_post( $request['id'], true );
        return rest_ensure_response( [ 'id' => $request['id'], 'status' => 'deleted' ] );
    }

    // ---- Team ----

    public function get_team() {
        $store = new ASSE_Data_Store();
        return rest_ensure_response( $store->get_team() );
    }

    public function create_team_member( $request ) {
        $params = $request->get_json_params() ?: $request->get_body_params();
        if ( empty( $params['name'] ) ) {
            return new WP_Error( 'missing_fields', 'Team member name is required', [ 'status' => 400 ] );
        }
        $id = wp_insert_post( [
            'post_type'    => 'asse_team',
            'post_title'   => sanitize_text_field( $params['name'] ),
            'post_content' => wp_kses_post( $params['bio'] ?? '' ),
            'post_status'  => 'publish',
        ]);
        if ( ! empty( $params['title'] ) ) {
            update_post_meta( $id, '_asse_team_title', sanitize_text_field( $params['title'] ) );
        }
        if ( ! empty( $params['specialty'] ) ) {
            update_post_meta( $id, '_asse_team_specialty', sanitize_text_field( $params['specialty'] ) );
        }
        return rest_ensure_response( [ 'id' => $id, 'name' => $params['name'], 'status' => 'created' ] );
    }

    public function update_team_member( $request ) {
        $id = $request['id'];
        $params = $request->get_json_params() ?: $request->get_body_params();
        $update = [ 'ID' => $id ];
        if ( isset( $params['name'] ) ) $update['post_title'] = sanitize_text_field( $params['name'] );
        if ( isset( $params['bio'] ) ) $update['post_content'] = wp_kses_post( $params['bio'] );
        wp_update_post( $update );
        if ( isset( $params['title'] ) ) update_post_meta( $id, '_asse_team_title', sanitize_text_field( $params['title'] ) );
        if ( isset( $params['specialty'] ) ) update_post_meta( $id, '_asse_team_specialty', sanitize_text_field( $params['specialty'] ) );
        return rest_ensure_response( [ 'id' => $id, 'status' => 'updated' ] );
    }

    public function delete_team_member( $request ) {
        wp_delete_post( $request['id'], true );
        return rest_ensure_response( [ 'id' => $request['id'], 'status' => 'deleted' ] );
    }

    // ---- Schema Preview ----

    public function get_schema_preview() {
        $output = new ASSE_Schema_Output();
        $reflection = new ReflectionClass( $output );
        $schemas = [];
        $methods = [
            'local_business' => 'get_local_business_schema',
            'faq'           => 'get_faq_schema',
            'service'       => 'get_service_schema',
            'review'        => 'get_review_schema',
            'team'          => 'get_team_schema',
        ];
        foreach ( $methods as $key => $method ) {
            if ( $reflection->hasMethod( $method ) ) {
                $m = $reflection->getMethod( $method );
                $m->setAccessible( true );
                $result = $m->invoke( $output );
                if ( $result ) {
                    $schemas[ $key ] = $result;
                }
            }
        }
        return rest_ensure_response( $schemas );
    }

    // ---- Health Check ----

    public function health_check() {
        return rest_ensure_response( [
            'plugin'  => 'AgentSocial Schema Engine',
            'version' => ASSE_VERSION,
            'status'  => 'active',
            'enabled' => (bool) get_option( 'asse_enabled', '1' ),
        ]);
    }
}