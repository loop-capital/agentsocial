# AgentSocial Schema Engine

Comprehensive schema markup engine for local businesses. Generates LocalBusiness, FAQ, Service, Review, and Team schema with remote API management.

## Features

### Schema Types Generated
- **LocalBusiness** (HealthAndBeautyBusiness / SalonOrSpa) — address, hours, geo, phone, price range
- **FAQPage** — configurable Q&A pairs for rich snippets and AI citation
- **Service** — per-service schema with categories and offer catalogs
- **Review** + **AggregateRating** — star ratings in search results
- **Person** — team/staff profiles for E-E-A-T authority signals

### Admin UI
- Business Info — name, address, phone, hours, geo coordinates, social links
- Services — add/edit/delete with categories
- FAQ — add/edit/delete Q&A pairs
- Reviews — add/edit/manage with author, rating, date
- Team — add/edit staff with title, specialty, bio, photo
- Schema Preview — see generated JSON-LD output

### Remote API (REST)
All data is manageable remotely via `/wp-json/asse/v1/` endpoints:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/business` | GET | Get all business settings |
| `/business` | POST | Update business settings |
| `/faqs` | GET | List FAQ items |
| `/faqs` | POST | Create FAQ item |
| `/faqs/{id}` | PUT | Update FAQ item |
| `/faqs/{id}` | DELETE | Delete FAQ item |
| `/services` | GET | List services |
| `/services` | POST | Create service |
| `/services/{id}` | PUT | Update service |
| `/services/{id}` | DELETE | Delete service |
| `/reviews` | GET | List reviews |
| `/reviews` | POST | Create review |
| `/reviews/{id}` | DELETE | Delete review |
| `/team` | GET | List team members |
| `/team` | POST | Create team member |
| `/team/{id}` | PUT | Update team member |
| `/team/{id}` | DELETE | Delete team member |
| `/schema-preview` | GET | View generated schema (public) |
| `/health` | GET | Plugin health check (public) |

**Authentication**: WordPress application passwords (Users → Profile → Application Passwords)

## Installation

1. Upload `agentsocial-schema-engine` folder to `/wp-content/plugins/`
2. Activate through WordPress admin → Plugins
3. Go to Schema Engine → Business Info and enter your details
4. Add FAQ items, services, reviews, and team members
5. Use Schema Preview to verify output

## Why This Over AIOSEO Pro

| | AIOSEO Pro ($99.50/yr) | AgentSocial Schema Engine |
|---|---|---|
| Cost | $99.50/yr per site | Free |
| Remote API | ❌ | ✅ Full CRUD |
| White-label | ❌ | ✅ AgentSocial branded |
| Salon defaults | ❌ Generic | ✅ SalonOrSpa default |
| AI integration | Basic ChatGPT | ✅ Full AgentSocial AI |
| DFY workflow | ❌ | ✅ Built for service model |

## License

Proprietary — AgentSocial. For use on AgentSocial DFY client sites only.